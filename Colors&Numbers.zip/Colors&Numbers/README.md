# Colors & Numbers

A SwiftUI-based colors & numbers game for iOS featuring:
- Colors & numbers catching mechanics with visual effects
- For colors: red, blue, green, yellow, purple, orange, white, black
- For numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
- Random colors comes on a train, color names on the top appear. Within a given period of time, catch the color.
- Random numbers come on a train, number names on the top appear. Within a given period of time, catch the number.
- Wrong catch will result in a penalty.
- The game will end when all the colors and numbers are caught.
- The player will get points for each correct catch.

## Game Description

In this game, kids try to catch colors and numbers with their fingers from a virtual train. The colors and numbers come on a train, and the names of the colors and numbers appear on the top. Within a given period of time, catch the color or number.

## Setup
1. Place color and number images in `Resources/Colors` directory
2. Place audio files in `Resources/Sounds` directory
3. Run the app in Xcode

## Features
- Different types of colors and numbers with unique appearnce
- Score tracking
- Timed gameplay
- Interactive touch contrances
lowing Apple design guidelines
- Immersive sound effects: atmosphere
  - Train sounds for an engaging atmosphere
  - Satisfying click sounds when catching colors or numbers
- Game has Easy, Medium, and Hard difficulty levels.
- Game has a main menu, game screen, and game over screen.
- Game has a timer and a score.
- Game has a leaderboard to track the best scores.
- Game has a settings screen to adjust sound volume.
- Game has a credits screen to show the credits.
- As the game gets more difficult, the speed of the train increases.
- The game ends when all the colors and numbers are caught.

## Installation

1. Clone this repository
2. Open the project in Xcode 15 or later
3. Add sound files (see Resources/README.txt for details)
4. Build and run on an iOS device or simulator running iOS 16.0 or later

## How to Play

1. Select a difficulty level (Easy, Medium, or Hard)
2. Tap "Start Game" to begin
3. Touch colors or numbers to catch them and score points
4. Try to catch as many colors or numbers as possible before time runs out
5. When the game ends, you can play again or return to the main menu

## Image Resources

To use free, open-license train and vagon (railcar) images suitable for children, you can download images from the following sources:

- [Cartoon Train Images on Pixabay](https://pixabay.com/images/search/cartoon%20train/)
- [Train Railroad Cartoon Illustration](https://pixabay.com/illustrations/train-railroad-cartoon-car-nature-7336833/)
- [Train Cartoon Images on Pixabay](https://pixabay.com/images/search/train%20cartoon/)
- [Cartoon Train Illustrations](https://pixabay.com/illustrations/search/cartoon%20train/)
- [Railway Cartoon Images](https://pixabay.com/images/search/railway%20cartoon/)

**Instructions:**
1. Download your preferred train and vagon images from the links above. Choose images that are colorful and visually appealing for children.
2. Place the images in the `Resources/Colors` directory as described in the Setup section.
3. Ensure each vagon image can be recolored or use different colored versions for the color game.
4. For the number game, you may add numbers to the vagon images using an image editor or overlay numbers programmatically in the app.

## Development

This game is built using:
- Swift 5.9
- SwiftUI
- AVFoundation for sound effects
- Follows Apple's design guidelines for touch interaction and accessibility

## Credits

Created based on Apple's UI Design Tips and best practices:
- [Apple UI Design Tips](https://developer.apple.com/design/tips/)
- [Swift Documentation](https://developer.apple.com/documentation/swift)
