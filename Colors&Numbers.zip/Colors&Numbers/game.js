// Game configuration
const config = {
    ballSize: 100,
    colors: ['black', 'blue', 'green', 'orange', 'purple', 'red', 'white', 'yellow'],
    numbers: Array.from({length: 20}, (_, i) => i + 1),
    spawnInterval: 2000,
    ballSpeed: 1.5,
    gameDuration: 60000,
    difficulty: 'medium',
    gravity: 0.03,
    bounceDamping: 0.75,
    sounds: {
        success: new Audio('./Sounds/Applause.mp3')
    }
};

// Number to words mapping
const numberWords = [
    'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
    'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'
];

// Helper function to get number word
function getNumberWord(num) {
    return numberWords[num] || num;
}

// Game state
let score = 0;
let gameArea = document.getElementById('gameArea');
let scoreElement = document.getElementById('score');
let gameActive = true;
let isPaused = false;
let activeColor = null;
let activeNumber = null;
let gameMode = null; // 'colors' or 'numbers'
let spawnIntervalId;
let gameTimeoutId;

// Show mode selection menu
function showModeMenu() {
    document.getElementById('modeMenu').style.display = 'block';
    document.getElementById('gameUI').style.display = 'none';
}

// Start game with selected mode
function startGameWithMode(mode) {
    gameMode = mode;
    document.getElementById('modeMenu').style.display = 'none';
    document.getElementById('gameUI').style.display = 'block';
    
    // Reset game state
    score = 0;
    scoreElement.textContent = '0';
    gameActive = true;
    isPaused = false;
    
    // Clear any existing game elements
    clearInterval(spawnIntervalId);
    clearTimeout(gameTimeoutId);
    gameArea.innerHTML = '';
    
    initGame();
}

// Initialize game
function initGame() {
    // Setup text grid based on mode
    if (gameMode === 'colors') {
        setupTextGrid('colorGrid', config.colors);
        document.getElementById('colorGrid').style.display = 'grid';
        document.getElementById('numberGrid').style.display = 'none';
    } else {
        setupTextGrid('numberGrid', config.numbers);
        document.getElementById('numberGrid').style.display = 'grid';
        document.getElementById('colorGrid').style.display = 'none';
    }

    // Setup grid click handlers using event delegation
    document.getElementById('colorGrid').addEventListener('click', function(e) {
        const item = e.target.closest('.grid-item');
        if (!item || !gameActive || isPaused) return;
        
        const clickedColor = item.dataset.value.toLowerCase();
        console.log('Clicked color:', clickedColor, 'Active color:', activeColor);
        
        if (clickedColor === activeColor?.toLowerCase()) {
            score += 10;
            scoreElement.textContent = score;
            try {
                config.sounds.success.currentTime = 0;
                config.sounds.success.play();
            } catch (e) {
                console.error('Sound playback failed:', e);
            }
            setRandomActiveItems();
            spawnBall(); // Immediate feedback
        }
    });

    document.getElementById('numberGrid').addEventListener('click', function(e) {
        const item = e.target.closest('.grid-item');
        if (!item || !gameActive || isPaused) return;
        
        const clickedNumber = parseInt(item.dataset.value);
        console.log('Clicked number:', clickedNumber, 'Active number:', activeNumber);
        
        if (clickedNumber === activeNumber) {
            score += 10;
            scoreElement.textContent = score;
            try {
                config.sounds.success.currentTime = 0;
                config.sounds.success.play();
            } catch (e) {
                console.error('Sound playback failed:', e);
            }
            setRandomActiveItems();
            spawnBall();
        }
    });

    // Setup buttons
    document.getElementById('easyBtn').addEventListener('click', () => setDifficulty('easy'));
    document.getElementById('mediumBtn').addEventListener('click', () => setDifficulty('medium'));
    document.getElementById('hardBtn').addEventListener('click', () => setDifficulty('hard'));
    document.getElementById('pauseBtn').addEventListener('click', togglePause);
    document.getElementById('restartBtn').addEventListener('click', restartGame);
    
    // Start game
    startGame();
}

function setupTextGrid(elementId, items) {
    const grid = document.getElementById(elementId);
    grid.innerHTML = '';
    
    items.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'grid-item';
        itemElement.dataset.value = item;
        
        if (elementId === 'colorGrid') {
            itemElement.textContent = item;
            itemElement.dataset.value = item.toLowerCase();
        } else { // Number grid
            const numberWord = getNumberWord(item);
            itemElement.textContent = `${item} - ${numberWord}`;
        }
        
        grid.appendChild(itemElement);
    });
}

function setActiveItem(type, item) {
    if (type === 'color') {
        activeColor = item.toLowerCase();
        document.querySelectorAll('#colorGrid .grid-item').forEach(el => {
            const isActive = el.dataset.value.toLowerCase() === activeColor;
            el.style.fontWeight = isActive ? 'bold' : 'normal';
            el.style.backgroundColor = isActive ? '#ffeb3b' : '';
        });
    } else {
        activeNumber = parseInt(item);
        document.querySelectorAll('#numberGrid .grid-item').forEach(el => {
            const isActive = parseInt(el.dataset.value) === activeNumber;
            el.style.fontWeight = isActive ? 'bold' : 'normal';
            el.style.backgroundColor = isActive ? '#ffeb3b' : '';
        });
    }
    console.log(`Active ${type}:`, type === 'color' ? activeColor : activeNumber);
}

function setRandomActiveItems() {
    if (gameMode === 'colors') {
        const randomColor = config.colors[Math.floor(Math.random() * config.colors.length)];
        setActiveItem('color', randomColor);
    } else {
        const randomNumber = config.numbers[Math.floor(Math.random() * config.numbers.length)];
        setActiveItem('number', randomNumber.toString());
    }
}

function setDifficulty(difficulty) {
    config.difficulty = difficulty;
    
    // Adjust game parameters based on difficulty
    switch(difficulty) {
        case 'easy':
            config.spawnInterval = 2000;
            config.ballSpeed = 1.5;
            config.gravity = 0.03;  // Reduced gravity
            config.bounceDamping = 0.7;  // Less damping on bounce
            break;
        case 'hard':
            config.spawnInterval = 1000;
            config.ballSpeed = 3;
            config.gravity = 0.1;
            config.bounceDamping = 0.8;
            break;
        default: // medium
            config.spawnInterval = 2000;
            config.ballSpeed = 1.5;
            config.gravity = 0.03;
            config.bounceDamping = 0.75;
    }
    
    // Restart game with new difficulty
    restartGame();
}

function startGame() {
    setRandomActiveItems();
    spawnIntervalId = setInterval(spawnBall, config.spawnInterval);
    gameTimeoutId = setTimeout(endGame, config.gameDuration);
}

function restartGame() {
    clearInterval(spawnIntervalId);
    clearTimeout(gameTimeoutId);
    startGame();
}

function togglePause() {
    isPaused = !isPaused;
    const pauseBtn = document.getElementById('pauseBtn');
    pauseBtn.textContent = isPaused ? 'Resume' : 'Pause';
}

function handleCorrectSelection() {
    score += 10;
    scoreElement.textContent = score;
    try {
        config.sounds.success.currentTime = 0;
        config.sounds.success.play();
    } catch (e) {
        console.error('Sound playback failed:', e);
    }
    setRandomActiveItems();
}

// Spawn a random ball
function spawnBall() {
    if (!gameActive || isPaused) return;
    
    const ball = document.createElement('div');
    ball.className = 'ball';
    ball.style.width = `${config.ballSize}px`;
    ball.style.height = `${config.ballSize}px`;
    
    if (gameMode === 'colors') {
        ball.style.backgroundColor = activeColor;
        ball.textContent = activeColor;
        ball.dataset.color = activeColor;
    } else {
        ball.style.backgroundImage = `url('./Numbers/${activeNumber}.png')`;
        ball.style.backgroundSize = 'cover';
        ball.dataset.number = activeNumber.toString();
    }
    
    const gameAreaWidth = gameArea.offsetWidth;
    const x = Math.random() * (gameAreaWidth - config.ballSize);
    ball.style.left = `${x}px`;
    ball.style.top = '0px';
    
    ball.addEventListener('click', handleBallClick);
    gameArea.appendChild(ball);
    animateBall(ball);
}

// Handle ball click
function handleBallClick(event) {
    if (!gameActive || isPaused) return;
    
    const ball = event.target;
    
    if (gameMode === 'colors') {
        if (ball.dataset.color === activeColor) {
            score += 10;
            scoreElement.textContent = score;
            try {
                config.sounds.success.currentTime = 0;
                config.sounds.success.play();
            } catch (e) {
                console.error('Sound playback failed:', e);
            }
            setRandomActiveItems();
        }
    } else {
        const ballNumber = parseInt(ball.dataset.number);
        if (ballNumber === activeNumber) {
            score += 10;
            scoreElement.textContent = score;
            try {
                config.sounds.success.currentTime = 0;
                config.sounds.success.play();
            } catch (e) {
                console.error('Sound playback failed:', e);
            }
            setRandomActiveItems();
        }
    }
    
    // Remove ball
    gameArea.removeChild(ball);
}

// Animate ball falling and bouncing
function animateBall(ball) {
    let y = 0;
    let ySpeed = config.ballSpeed;
    const gameAreaHeight = gameArea.offsetHeight;
    
    function move() {
        if (!gameActive || isPaused) return;
        
        y += ySpeed;
        
        // Bounce at bottom
        if (y + config.ballSize > gameAreaHeight) {
            y = gameAreaHeight - config.ballSize;
            ySpeed = -ySpeed * config.bounceDamping; // Use config damping
            
            // Remove ball if it's barely moving
            if (Math.abs(ySpeed) < 0.5) {
                gameArea.removeChild(ball);
                return;
            }
        }
        
        // Apply gravity from config
        if (ySpeed < 0) {
            ySpeed += config.gravity;
        } else {
            ySpeed += config.gravity;
        }
        
        ball.style.top = `${y}px`;
        requestAnimationFrame(move);
    }
    
    move();
}

// Show mode menu on initial load
showModeMenu();
